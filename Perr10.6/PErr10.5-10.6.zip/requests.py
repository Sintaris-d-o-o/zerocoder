import requests #библиотека для запросов API
#Заголовки запроса/безопасность
headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer 4d9e88d250ec15cfd2245906ee4e14ca8fc24e8a40b67a1c32006bb362489a40"
}
#запрос к 8n для генерации
r = requests.post("http://213.139.229.183:5678/webhook/generate-post", json={"topic":"AI в сфере обучения"}, headers=headers)
#Вывод статус кода от n8n:
#200 - удачно, всё прошло как надо
#404 - не тот url
#403 - проблема с headers, нет доступа
#Любой другой код ошибки - https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status
#Ищем по нашей цифре ошибку и смотрим что не так
print(r.status_code)