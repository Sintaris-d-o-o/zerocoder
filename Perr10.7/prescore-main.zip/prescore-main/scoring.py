"""Логика эвристической оценки и хранения истории."""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Dict, Iterable, List

from models import AssessmentResponse, HistoryEntry


HISTORY_FILE = Path(__file__).parent / "history.json"
SOFT_SKILLS = (
    "communication",
    "teamwork",
    "leadership",
    "adaptability",
    "initiative",
    "problem-solving",
    "creativity",
    "trust",
    "empathy",
    "critical thinking",
)


def _normalize_weights(weights: Dict[str, float]) -> Dict[str, float]:
    """Нормализует веса, чтобы их сумма равнялась 1 и возвращает значения по умолчанию при необходимости."""
    total = sum(weights.values())
    if not total:
        logging.debug("Сумма весов равна нулю, используются значения по умолчанию.")
        return {"hard": 0.6, "experience": 0.25, "soft": 0.15}
    # Делим каждый вес на общую сумму, чтобы получить долю от общего веса
    return {key: value / total for key, value in weights.items()}


def _token_set(text: str) -> Iterable[str]:
    """Извлекает уникальные токены длиной от четырех символов из текста для сопоставления навыков."""
    return set(
        token.lower()
        for token in re.findall(r"\b[\wа-яёА-ЯЁ]{4,}\b", text)
        if len(token) >= 4
    )


def calculate_hard_skill_score(vacancy: str, resume: str) -> float:
    """Оценивает процент совпадений ключевых навыков между вакансией и резюме."""
    vacancy_tokens = _token_set(vacancy)
    resume_tokens = _token_set(resume)
    if not vacancy_tokens:
        return 0.0
    match_count = len(vacancy_tokens & resume_tokens)
    return round((match_count / len(vacancy_tokens)) * 100, 2)


def calculate_experience_score(resume: str) -> float:
    """Извлекает годы опыта и масштабирует результат до диапазона 0-100 на основе верхнего предела."""
    years = [float(match) for match in re.findall(r"(\d+(?:\.\d+)?)\s*(?:years?|лет|yrs|года|год)", resume, flags=re.IGNORECASE)]
    extracted = max(years, default=0.0)
    scaled = min(extracted, 15.0) / 15.0
    return round(scaled * 100, 2)


def calculate_soft_skill_score(resume: str) -> float:
    """Определяет процент упоминаний мягких навыков в резюме по сравнению со списком ключевых компетенций."""
    normalized_text = resume.lower()
    matches = sum(1 for skill in SOFT_SKILLS if skill in normalized_text)
    if not SOFT_SKILLS:
        return 0.0
    return round((matches / len(SOFT_SKILLS)) * 100, 2)


def calculate_heuristic_score(
    vacancy: str, resume: str, weights: Dict[str, float]
) -> Dict[str, float]:
    normalized_weights = _normalize_weights(weights)
    hard = calculate_hard_skill_score(vacancy, resume)
    experience = calculate_experience_score(resume)
    soft = calculate_soft_skill_score(resume)
    weighted = (
        hard * normalized_weights["hard"]
        + experience * normalized_weights["experience"]
        + soft * normalized_weights["soft"]
    )
    return {
        "hard": hard,
        "experience": experience,
        "soft": soft,
        "heuristic": round(weighted, 2),
        "ratios": normalized_weights,
    }


def calculate_final_score(heuristic_score: float, gpt_score: int) -> int:
    """Сочетает эвристическую и GPT-оценки по фиксированным коэффициентам для получения итогового балла."""
    final = (heuristic_score * 0.45) + (gpt_score * 0.55)
    return min(100, max(0, int(round(final))))


def load_history() -> List[HistoryEntry]:
    """Возвращает ранее сохраненные оценки, если файл истории доступен."""
    if not HISTORY_FILE.exists():
        return []
    try:
        with HISTORY_FILE.open(encoding="utf-8") as handler:
            data = json.load(handler)
        return [HistoryEntry.parse_obj(entry) for entry in data]
    except Exception:
        logging.exception("Не удалось загрузить историю оценок")
        return []


def _persist_history(history: List[HistoryEntry]) -> None:
    """Сохраняет обновленную историю оценок в файл в читаемом формате JSON."""
    HISTORY_FILE.parent.mkdir(exist_ok=True)
    with HISTORY_FILE.open("w", encoding="utf-8") as handler:
        sanitized = []
        for entry in history:
            record = entry.dict()
            record["timestamp"] = entry.timestamp.isoformat()
            sanitized.append(record)
        json.dump(sanitized, handler, ensure_ascii=False, indent=2)


def append_history(entry: HistoryEntry) -> None:
    history = load_history()
    history.append(entry)
    _persist_history(history)


def build_history_entry(
    candidate_name: str,
    vacancy: str,
    assessment: AssessmentResponse,
    heuristic_details: Dict[str, float],
    final_score: int,
) -> HistoryEntry:
    return HistoryEntry(
        candidate_name=candidate_name,
        vacancy_snippet=vacancy.strip()[:300],
        final_score=final_score,
        gpt_score=assessment.score,
        heuristic_score=heuristic_details["heuristic"],
        ratios={
            "hard": round(heuristic_details["ratios"]["hard"], 2),
            "experience": round(heuristic_details["ratios"]["experience"], 2),
            "soft": round(heuristic_details["ratios"]["soft"], 2),
        },
        gpt_response=assessment,
    )
